import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-form-table',
  templateUrl: './employee-form-table.component.html',
  styleUrls: ['./employee-form-table.component.css']
})
export class EmployeeFormTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
