export interface Employee {
    idNo: number,
    employee_name: string,
    date: Date,
    project: string,
    task: string,
    hours: number,
    status: string,
    comments: string
}